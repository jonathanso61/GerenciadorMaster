package com.ifmg.gerenciadordetarefas
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.content.BroadcastReceiver

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra("taskId", -1)

        if (taskId != -1L) {
            scheduleNotification(context, taskId)
        }
    }

    private fun scheduleNotification(context: Context, taskId: Long) {
        val task = TaskDBHelper(context).getTask(taskId)

        if (task != null) {
            val notificationIntent = Intent(context, TaskNotificationReceiver::class.java)
            notificationIntent.putExtra("taskId", taskId)

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )

            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

            // Obtenha a data e hora da tarefa
            val dateTime = task.getDateTimeMillis()

            // Defina o alarme para a data e hora da tarefa
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    dateTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    dateTime,
                    pendingIntent
                )
            }
        }
    }
}
